
<nav class="navbar navbar-default navbar-fixed-bottom">
  <div class="container">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <span class="navbar-text">&copy; <span style="font-weight:bold;">Jens Vogler</span>, Nikola Lapcic, Manuel Ryffel, Maulana Arschhaar</span>
      </div>
    </div><!-- /.container-fluid -->
  </div>
</nav>


<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="scripts/bootstrap.min.js"></script>
</body>
</html>
