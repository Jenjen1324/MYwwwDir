<?php
$_TITLE = "Index";

include("resources/head.php");

include("resources/navbar.php");

?>

<div class="container">

<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ac augue mauris. Phasellus porta rutrum purus a rhoncus. Phasellus molestie sem id ante pharetra lobortis. Donec iaculis sapien odio, fermentum condimentum leo mollis in. Maecenas porta convallis leo, luctus dapibus velit. Donec vitae viverra massa. Fusce at egestas sem. Nullam molestie lacinia posuere. Suspendisse non enim nec turpis tempus porttitor quis a ex. Sed mollis turpis ac augue ornare, id pretium nunc rhoncus. Duis nec lacus dolor.
</p>
<p>
Sed dapibus est sit amet accumsan rutrum. Praesent non orci ex. Quisque bibendum semper eros eu accumsan. Nam maximus, neque vel eleifend luctus, purus tellus placerat tellus, non ornare dolor nisl id tortor. Sed eget venenatis eros, et ultrices nisi. Praesent odio diam, tempor eu ante ac, porta feugiat tortor. Cras feugiat lobortis facilisis. Duis sit amet lorem odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Etiam aliquet magna a ligula elementum hendrerit. Phasellus nec bibendum sem, vitae vehicula dolor. Nunc vulputate, dolor et faucibus fermentum, sem lorem mattis metus, non tincidunt nulla risus sodales sem.
</p>
<p>
Suspendisse scelerisque in purus quis tempor. Quisque semper tellus at urna ultricies, sit amet bibendum sem dignissim. Vestibulum auctor malesuada dignissim. Donec quis pretium lacus, non ultricies nibh. Morbi purus elit, molestie eu nunc et, ornare vestibulum eros. Cras ac dictum risus, a tincidunt felis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc gravida finibus nisi, sed ornare lorem suscipit id. Nullam lobortis quis massa vel aliquam. Maecenas elementum aliquet mauris. In ex nibh, tincidunt sed aliquam nec, consequat in elit. In porta sagittis sapien sit amet tempor.
</p>
<p>
Donec pellentesque in quam eu pretium. Morbi quis justo quis magna faucibus consequat et sed mi. Praesent at bibendum velit. Praesent ultrices, ex faucibus aliquet euismod, massa justo ullamcorper odio, pretium mollis orci erat sit amet sapien. Praesent venenatis justo eros, a venenatis lacus iaculis non. Fusce porttitor odio mauris, dictum rutrum tortor scelerisque vel. In faucibus vulputate condimentum.
</p>
<p>
Etiam malesuada lacus ut felis gravida dapibus. Cras sit amet risus nisi. Praesent fringilla ultricies pretium. In hac habitasse platea dictumst. Morbi ligula elit, congue vel diam sit amet, fermentum suscipit turpis. Ut fringilla eu nunc sed suscipit. Ut luctus odio velit, vel pharetra lacus eleifend a. Etiam aliquet elit quis quam venenatis egestas. Fusce tincidunt mollis nisi vel volutpat.
</p>

</div>

<?php

include("resources/footer.php");

?>
